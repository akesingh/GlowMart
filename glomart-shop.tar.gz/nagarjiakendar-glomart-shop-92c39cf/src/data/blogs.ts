import type { BlogPost } from "@/lib/types";

export const blogPosts: BlogPost[] = [
  {
    id: "blog1",
    slug: "build-a-glowing-skincare-routine",
    title: "How to Build a Glowing Skincare Routine in 5 Steps",
    excerpt:
      "From cleanser to SPF — a simple framework that works for most skin types without overcomplicating your shelf.",
    image: "/images/blog/skincare-routine.svg",
    category: "Skincare",
    author: "Ananya Mehta",
    date: "2026-08-12",
    readTime: "6 min",
  },
  {
    id: "blog2",
    slug: "matte-lipstick-guide",
    title: "The Modern Matte Lipstick Guide: Shades & Application Tips",
    excerpt:
      "Find your perfect nude, berry, or bold — plus pro tricks for crisp edges and comfortable wear.",
    image: "/images/blog/lipstick-guide.svg",
    category: "Makeup",
    author: "Riya Kapoor",
    date: "2026-08-20",
    readTime: "5 min",
  },
  {
    id: "blog3",
    slug: "monsoon-haircare",
    title: "Monsoon Haircare: Frizz Control That Actually Works",
    excerpt:
      "Humidity-proofing your hair with the right wash day routine, serums, and protective styles.",
    image: "/images/blog/haircare.svg",
    category: "Haircare",
    author: "Neha Joshi",
    date: "2026-08-28",
    readTime: "4 min",
  },
  {
    id: "blog4",
    slug: "layering-fragrances",
    title: "Fragrance Layering 101: Create Your Signature Scent",
    excerpt:
      "Learn how to combine body mist, attar, and eau de parfum for a scent trail that feels uniquely yours.",
    image: "/images/blog/fragrance.svg",
    category: "Fragrance",
    author: "Kabir Shah",
    date: "2026-08-05",
    readTime: "7 min",
  },
];
