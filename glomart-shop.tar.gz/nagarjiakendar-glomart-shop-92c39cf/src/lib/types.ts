export type CategorySlug =
  | "makeup"
  | "skincare"
  | "haircare"
  | "fragrance"
  | "bath-body"
  | "mens-grooming"
  | "beauty-tools";

export type ProductBadge = "New" | "Bestseller" | "Limited" | "Exclusive" | "Deal";

export interface Category {
  id: string;
  name: string;
  slug: CategorySlug;
  description: string;
  image: string;
  subcategories: string[];
  accent: string;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo: string;
  description: string;
  featured: boolean;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  brand: string;
  brandSlug: string;
  category: CategorySlug;
  subcategory: string;
  description: string;
  longDescription: string;
  price: number;
  mrp: number;
  discount: number;
  rating: number;
  reviewCount: number;
  images: string[];
  shades?: string[];
  sizes?: string[];
  badges: ProductBadge[];
  tags: string[];
  ingredients?: string[];
  howToUse?: string;
  inStock: boolean;
  isTrending?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isDeal?: boolean;
}

export interface Review {
  id: string;
  productId: string;
  author: string;
  rating: number;
  title: string;
  body: string;
  date: string;
  verified: boolean;
  helpful: number;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  image: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
  shade?: string;
  size?: string;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export type SortOption =
  | "relevance"
  | "price-asc"
  | "price-desc"
  | "rating"
  | "newest"
  | "discount";

export interface ProductFilters {
  categories?: CategorySlug[];
  brands?: string[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  badges?: ProductBadge[];
  inStock?: boolean;
  search?: string;
  sort?: SortOption;
}

export interface CheckoutAddress {
  fullName: string;
  email: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface PaymentInfo {
  method: "card" | "upi" | "cod" | "wallet";
  cardNumber?: string;
  cardName?: string;
  expiry?: string;
  cvv?: string;
  upiId?: string;
}
