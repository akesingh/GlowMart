"use client";

import { useEffect, useState, useTransition } from "react";
import { useSearchParams } from "next/navigation";
import { searchProducts } from "@/services/search-service";
import { ProductGrid } from "@/components/product/product-grid";
import type { Product } from "@/lib/types";
import { SearchAutocomplete } from "@/components/layout/search-autocomplete";
import { getPopularSearches } from "@/services/search-service";
import Link from "next/link";

export function SearchPageClient() {
  const params = useSearchParams();
  const q = params.get("q") || "";
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [, startTransition] = useTransition();
  const popular = getPopularSearches();

  useEffect(() => {
    if (!q.trim()) {
      setProducts([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    startTransition(async () => {
      const results = await searchProducts(q);
      if (!cancelled) {
        setProducts(results);
        setLoading(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [q]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <h1 className="font-heading text-3xl text-[var(--ink)] sm:text-4xl">Search</h1>
      <div className="mt-4 max-w-xl md:hidden">
        <SearchAutocomplete />
      </div>

      {!q ? (
        <div className="mt-10">
          <p className="text-sm text-muted-foreground">Popular searches</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {popular.map((term) => (
              <Link
                key={term}
                href={`/search?q=${encodeURIComponent(term)}`}
                className="rounded-full border border-[var(--blush)] bg-white px-4 py-2 text-sm transition hover:border-[var(--rose)] hover:bg-[var(--blush-soft)]"
              >
                {term}
              </Link>
            ))}
          </div>
        </div>
      ) : (
        <>
          <p className="mt-3 text-sm text-muted-foreground">
            {loading
              ? "Searching..."
              : `${products.length} results for “${q}”`}
          </p>
          <div className="mt-8">
            <ProductGrid
              products={products}
              loading={loading}
              emptyMessage={`No products matched “${q}”. Try another keyword or browse categories.`}
            />
          </div>
        </>
      )}
    </div>
  );
}
