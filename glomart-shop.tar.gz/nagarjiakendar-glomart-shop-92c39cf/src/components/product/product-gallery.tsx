"use client";

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

interface ProductGalleryProps {
  images: string[];
  name: string;
}

export function ProductGallery({ images, name }: ProductGalleryProps) {
  const [active, setActive] = useState(0);
  const current = images[active] ?? images[0];

  return (
    <div className="flex flex-col gap-3 sm:flex-row">
      <div className="order-2 flex gap-2 overflow-x-auto sm:order-1 sm:w-20 sm:flex-col">
        {images.map((src, i) => (
          <button
            key={src + i}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`View image ${i + 1}`}
            aria-current={i === active}
            className={cn(
              "relative size-16 shrink-0 overflow-hidden rounded-xl ring-1 transition sm:w-full sm:size-auto sm:aspect-square",
              i === active
                ? "ring-[var(--rose)] ring-2"
                : "ring-[var(--blush)] hover:ring-[var(--rose)]/50"
            )}
          >
            <Image src={src} alt="" fill className="object-cover" sizes="80px" />
          </button>
        ))}
      </div>
      <div className="relative order-1 aspect-[4/5] flex-1 overflow-hidden rounded-2xl bg-[var(--blush-soft)] sm:order-2">
        <Image
          src={current}
          alt={name}
          fill
          priority
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 45vw"
        />
      </div>
    </div>
  );
}
