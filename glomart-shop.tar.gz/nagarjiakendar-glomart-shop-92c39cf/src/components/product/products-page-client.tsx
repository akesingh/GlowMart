"use client";

import { useEffect, useState, useTransition } from "react";
import { useSearchParams } from "next/navigation";
import { ProductFilters, SortSelect } from "@/components/product/product-filters";
import { ProductGrid } from "@/components/product/product-grid";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { getProducts } from "@/services/product-service";
import type { CategorySlug, Product, SortOption } from "@/lib/types";
import { SlidersHorizontal } from "lucide-react";
import { categories } from "@/data/categories";
import { brands } from "@/data/brands";

export function ProductsPageClient() {
  const params = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPending, startTransition] = useTransition();
  const [filtersOpen, setFiltersOpen] = useState(false);

  const categoryParams = params.getAll("category") as CategorySlug[];
  const brandParams = params.getAll("brand");
  const sub = params.get("sub");
  const sort = (params.get("sort") as SortOption) || "relevance";
  const minPrice = params.get("minPrice");
  const maxPrice = params.get("maxPrice");
  const minRating = params.get("minRating");
  const q = params.get("q");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    startTransition(async () => {
      let result = await getProducts({
        categories: categoryParams.length ? categoryParams : undefined,
        brands: brandParams.length ? brandParams : undefined,
        minPrice: minPrice ? Number(minPrice) : undefined,
        maxPrice: maxPrice ? Number(maxPrice) : undefined,
        minRating: minRating ? Number(minRating) : undefined,
        search: q || undefined,
        sort,
      });

      if (sub) {
        result = result.filter(
          (p) => p.subcategory.toLowerCase() === sub.toLowerCase()
        );
      }

      if (!cancelled) {
        setProducts(result);
        setLoading(false);
      }
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.toString()]);

  const title =
    categoryParams.length === 1
      ? categories.find((c) => c.slug === categoryParams[0])?.name || "Products"
      : brandParams.length === 1
        ? brands.find((b) => b.slug === brandParams[0])?.name || "Products"
        : "All products";

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
            Shop
          </p>
          <h1 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">
            {title}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {loading || isPending ? "Loading..." : `${products.length} products`}
            {sub ? ` · ${sub}` : ""}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
            <SheetTrigger className="inline-flex h-9 items-center gap-2 rounded-lg border border-[var(--blush)] px-3 text-sm lg:hidden">
              <SlidersHorizontal className="size-4" />
              Filters
            </SheetTrigger>
            <SheetContent side="left" className="w-[min(100%,340px)] overflow-y-auto p-5">
              <SheetHeader className="mb-4 p-0">
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <ProductFilters onApply={() => setFiltersOpen(false)} />
            </SheetContent>
          </Sheet>
          <SortSelect />
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <ProductFilters className="hidden lg:block" />
        <ProductGrid products={products} loading={loading || isPending} />
      </div>
    </div>
  );
}
