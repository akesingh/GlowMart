"use client";

import { useState } from "react";
import { Heart, ShoppingBag, Minus, Plus, Truck, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import type { Product, Review } from "@/lib/types";
import { formatINR } from "@/lib/format";
import { StarRating } from "@/components/ui/star-rating";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ProductGallery } from "@/components/product/product-gallery";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { cn } from "@/lib/utils";

interface ProductDetailProps {
  product: Product;
  reviews: Review[];
}

export function ProductDetail({ product, reviews }: ProductDetailProps) {
  const [shade, setShade] = useState(product.shades?.[0]);
  const [size, setSize] = useState(product.sizes?.[0]);
  const [qty, setQty] = useState(1);
  const addItem = useCartStore((s) => s.addItem);
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const inWishlist = useWishlistStore((s) => s.productIds.includes(product.id));

  const addToBag = () => {
    addItem({
      productId: product.id,
      quantity: qty,
      shade,
      size,
    });
    toast.success("Added to bag", { description: product.name });
  };

  return (
    <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
      <ProductGallery images={product.images} name={product.name} />

      <div>
        <p className="text-xs font-semibold tracking-[0.16em] text-[var(--rose-deep)] uppercase">
          {product.brand}
        </p>
        <h1 className="font-heading mt-2 text-3xl text-[var(--ink)] sm:text-4xl">
          {product.name}
        </h1>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <StarRating rating={product.rating} reviewCount={product.reviewCount} size="md" />
          <div className="flex gap-1.5">
            {product.badges.map((b) => (
              <Badge
                key={b}
                className="rounded-md border-0 bg-[var(--blush-soft)] text-[var(--rose-deep)]"
              >
                {b}
              </Badge>
            ))}
          </div>
        </div>

        <div className="mt-5 flex items-baseline gap-3">
          <span className="text-3xl font-semibold text-[var(--ink)]">
            {formatINR(product.price)}
          </span>
          <span className="text-base text-muted-foreground line-through">
            {formatINR(product.mrp)}
          </span>
          <span className="text-sm font-semibold text-emerald-700">
            {product.discount}% off
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Inclusive of all taxes</p>

        <p className="mt-5 text-sm leading-relaxed text-[var(--ink)]/75">
          {product.description}
        </p>

        {product.shades && (
          <div className="mt-6">
            <p className="text-sm font-medium">
              Shade: <span className="text-muted-foreground">{shade}</span>
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {product.shades.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShade(s)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-medium transition",
                    shade === s
                      ? "border-[var(--rose)] bg-[var(--blush-soft)] text-[var(--rose-deep)]"
                      : "border-[var(--blush)] hover:border-[var(--rose)]/50"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {product.sizes && (
          <div className="mt-6">
            <p className="text-sm font-medium">
              Size: <span className="text-muted-foreground">{size}</span>
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSize(s)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-medium transition",
                    size === s
                      ? "border-[var(--rose)] bg-[var(--blush-soft)] text-[var(--rose-deep)]"
                      : "border-[var(--blush)] hover:border-[var(--rose)]/50"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6 flex items-center gap-3">
          <div className="flex h-11 items-center rounded-full border border-[var(--blush)]">
            <button
              type="button"
              aria-label="Decrease quantity"
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="flex size-11 items-center justify-center"
            >
              <Minus className="size-4" />
            </button>
            <span className="w-8 text-center text-sm font-medium">{qty}</span>
            <button
              type="button"
              aria-label="Increase quantity"
              onClick={() => setQty((q) => Math.min(10, q + 1))}
              className="flex size-11 items-center justify-center"
            >
              <Plus className="size-4" />
            </button>
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <Button
            onClick={addToBag}
            disabled={!product.inStock}
            className="h-12 flex-1 rounded-full bg-[var(--ink)] text-sm font-medium hover:bg-[var(--rose-deep)]"
          >
            <ShoppingBag className="size-4" />
            Add to Bag
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const added = toggleWishlist(product.id);
              toast.success(added ? "Saved to wishlist" : "Removed from wishlist");
            }}
            className="h-12 rounded-full border-[var(--blush)]"
          >
            <Heart className={cn("size-4", inWishlist && "fill-[var(--rose)] text-[var(--rose)]")} />
            Wishlist
          </Button>
        </div>

        <div className="mt-6 grid gap-3 rounded-2xl border border-[var(--blush)] bg-[var(--blush-soft)]/40 p-4 sm:grid-cols-2">
          <div className="flex items-center gap-2 text-sm">
            <Truck className="size-4 text-[var(--rose-deep)]" />
            Free delivery above ₹799
          </div>
          <div className="flex items-center gap-2 text-sm">
            <ShieldCheck className="size-4 text-[var(--rose-deep)]" />
            100% authentic product
          </div>
        </div>

        <div className="mt-8 space-y-4 border-t border-[var(--blush)] pt-6">
          <details open className="group">
            <summary className="cursor-pointer list-none font-medium text-[var(--ink)]">
              About this product
            </summary>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {product.longDescription}
            </p>
          </details>
          {product.howToUse && (
            <details className="group">
              <summary className="cursor-pointer list-none font-medium text-[var(--ink)]">
                How to use
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {product.howToUse}
              </p>
            </details>
          )}
          {product.ingredients && (
            <details className="group">
              <summary className="cursor-pointer list-none font-medium text-[var(--ink)]">
                Key ingredients
              </summary>
              <ul className="mt-2 list-inside list-disc text-sm text-muted-foreground">
                {product.ingredients.map((ing) => (
                  <li key={ing}>{ing}</li>
                ))}
              </ul>
            </details>
          )}
        </div>

        <div className="mt-10">
          <h2 className="font-heading text-2xl text-[var(--ink)]">Customer reviews</h2>
          {reviews.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">No reviews yet for this product.</p>
          ) : (
            <ul className="mt-4 space-y-4">
              {reviews.map((r) => (
                <li
                  key={r.id}
                  className="rounded-2xl border border-[var(--blush)] bg-white p-4"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm">{r.author}</p>
                    <StarRating rating={r.rating} showValue={false} />
                  </div>
                  <p className="mt-1 text-sm font-medium">{r.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{r.body}</p>
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    {r.verified && "Verified purchase · "}
                    {new Date(r.date).toLocaleDateString("en-IN", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
