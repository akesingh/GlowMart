"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useMemo, useTransition } from "react";
import { brands } from "@/data/brands";
import { categories } from "@/data/categories";
import type { CategorySlug, SortOption } from "@/lib/types";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";

const priceRanges = [
  { label: "Under ₹500", min: 0, max: 499 },
  { label: "₹500 – ₹999", min: 500, max: 999 },
  { label: "₹1,000 – ₹1,999", min: 1000, max: 1999 },
  { label: "₹2,000+", min: 2000, max: 100000 },
];

const ratingOptions = [4, 3];

interface ProductFiltersProps {
  className?: string;
  onApply?: () => void;
}

export function ProductFilters({ className, onApply }: ProductFiltersProps) {
  const router = useRouter();
  const params = useSearchParams();
  const [, startTransition] = useTransition();

  const selectedCategories = params.getAll("category") as CategorySlug[];
  const selectedBrands = params.getAll("brand");
  const minPrice = params.get("minPrice");
  const maxPrice = params.get("maxPrice");
  const minRating = params.get("minRating");

  const update = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      startTransition(() => {
        router.push(`/products?${next.toString()}`);
        onApply?.();
      });
    },
    [params, router, onApply]
  );

  const toggleParam = (key: string, value: string) => {
    update((next) => {
      const values = next.getAll(key);
      next.delete(key);
      if (values.includes(value)) {
        values.filter((v) => v !== value).forEach((v) => next.append(key, v));
      } else {
        [...values, value].forEach((v) => next.append(key, v));
      }
    });
  };

  const setPrice = (min: number, max: number) => {
    update((next) => {
      if (minPrice === String(min) && maxPrice === String(max)) {
        next.delete("minPrice");
        next.delete("maxPrice");
      } else {
        next.set("minPrice", String(min));
        next.set("maxPrice", String(max));
      }
    });
  };

  const clearAll = () => {
    startTransition(() => {
      router.push("/products");
      onApply?.();
    });
  };

  const hasFilters =
    selectedCategories.length +
      selectedBrands.length +
      (minPrice ? 1 : 0) +
      (minRating ? 1 : 0) >
    0;

  return (
    <aside className={cn("space-y-7", className)}>
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-xl text-[var(--ink)]">Filters</h2>
        {hasFilters && (
          <button
            type="button"
            onClick={clearAll}
            className="inline-flex items-center gap-1 text-xs font-medium text-[var(--rose-deep)]"
          >
            <X className="size-3.5" /> Clear all
          </button>
        )}
      </div>

      <FilterGroup title="Category">
        {categories.map((c) => (
          <label key={c.id} className="flex cursor-pointer items-center gap-2.5 text-sm">
            <Checkbox
              checked={selectedCategories.includes(c.slug)}
              onCheckedChange={() => toggleParam("category", c.slug)}
            />
            {c.name}
          </label>
        ))}
      </FilterGroup>

      <FilterGroup title="Brand">
        {brands.map((b) => (
          <label key={b.id} className="flex cursor-pointer items-center gap-2.5 text-sm">
            <Checkbox
              checked={selectedBrands.includes(b.slug)}
              onCheckedChange={() => toggleParam("brand", b.slug)}
            />
            {b.name}
          </label>
        ))}
      </FilterGroup>

      <FilterGroup title="Price">
        {priceRanges.map((r) => {
          const active = minPrice === String(r.min) && maxPrice === String(r.max);
          return (
            <button
              key={r.label}
              type="button"
              onClick={() => setPrice(r.min, r.max)}
              className={cn(
                "block w-full rounded-lg px-2.5 py-2 text-left text-sm transition",
                active
                  ? "bg-[var(--blush-soft)] font-medium text-[var(--rose-deep)]"
                  : "hover:bg-[var(--blush-soft)]/60"
              )}
            >
              {r.label}
            </button>
          );
        })}
      </FilterGroup>

      <FilterGroup title="Rating">
        {ratingOptions.map((r) => (
          <button
            key={r}
            type="button"
            onClick={() =>
              update((next) => {
                if (minRating === String(r)) next.delete("minRating");
                else next.set("minRating", String(r));
              })
            }
            className={cn(
              "block w-full rounded-lg px-2.5 py-2 text-left text-sm transition",
              minRating === String(r)
                ? "bg-[var(--blush-soft)] font-medium text-[var(--rose-deep)]"
                : "hover:bg-[var(--blush-soft)]/60"
            )}
          >
            {r}★ & above
          </button>
        ))}
      </FilterGroup>
    </aside>
  );
}

function FilterGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <p className="mb-3 text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase">
        {title}
      </p>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

export function SortSelect() {
  const router = useRouter();
  const params = useSearchParams();
  const sort = (params.get("sort") as SortOption) || "relevance";

  const options: { value: SortOption; label: string }[] = useMemo(
    () => [
      { value: "relevance", label: "Relevance" },
      { value: "price-asc", label: "Price: Low to High" },
      { value: "price-desc", label: "Price: High to Low" },
      { value: "rating", label: "Customer Rating" },
      { value: "newest", label: "Newest" },
      { value: "discount", label: "Discount" },
    ],
    []
  );

  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="text-muted-foreground">Sort by</span>
      <select
        value={sort}
        onChange={(e) => {
          const next = new URLSearchParams(params.toString());
          next.set("sort", e.target.value);
          router.push(`/products?${next.toString()}`);
        }}
        className="h-9 rounded-lg border border-[var(--blush)] bg-white px-3 text-sm outline-none focus:border-[var(--rose)]"
        aria-label="Sort products"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
