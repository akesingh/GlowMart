"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import type { Product } from "@/lib/types";
import { formatINR, formatReviewCount } from "@/lib/format";
import { StarRating } from "@/components/ui/star-rating";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  className?: string;
  priority?: boolean;
}

export function ProductCard({ product, className, priority }: ProductCardProps) {
  const addItem = useCartStore((s) => s.addItem);
  const toggleWishlist = useWishlistStore((s) => s.toggle);
  const inWishlist = useWishlistStore((s) => s.productIds.includes(product.id));

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      productId: product.id,
      quantity: 1,
      shade: product.shades?.[0],
      size: product.sizes?.[0],
    });
    toast.success("Added to bag", {
      description: product.name,
    });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const added = toggleWishlist(product.id);
    toast.success(added ? "Saved to wishlist" : "Removed from wishlist", {
      description: product.name,
    });
  };

  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-xl bg-white transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_12px_40px_-12px_rgba(92,42,50,0.18)]",
        className
      )}
    >
      <Link href={`/products/${product.slug}`} className="flex flex-1 flex-col">
        <div className="relative aspect-[4/5] overflow-hidden bg-[var(--blush-soft)]">
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            priority={priority}
          />
          <div className="absolute left-2.5 top-2.5 flex flex-col gap-1">
            {product.badges.map((badge) => (
              <Badge
                key={badge}
                className={cn(
                  "rounded-md border-0 px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase",
                  badge === "New" && "bg-emerald-700 text-white",
                  badge === "Bestseller" && "bg-[var(--rose)] text-white",
                  badge === "Deal" && "bg-amber-600 text-white",
                  badge === "Limited" && "bg-stone-800 text-white",
                  badge === "Exclusive" && "bg-[var(--rose-deep)] text-white"
                )}
              >
                {badge}
              </Badge>
            ))}
          </div>
          <button
            type="button"
            onClick={handleWishlist}
            aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
            className="absolute right-2.5 top-2.5 flex size-9 items-center justify-center rounded-full bg-white/90 text-[var(--ink)] shadow-sm backdrop-blur transition hover:scale-105 hover:bg-white"
          >
            <Heart
              className={cn(
                "size-4 transition-colors",
                inWishlist && "fill-[var(--rose)] text-[var(--rose)]"
              )}
            />
          </button>
        </div>

        <div className="flex flex-1 flex-col gap-1.5 p-3 sm:p-3.5">
          <p className="text-[11px] font-semibold tracking-[0.12em] text-[var(--rose-deep)] uppercase">
            {product.brand}
          </p>
          <h3 className="line-clamp-2 text-sm leading-snug font-medium text-[var(--ink)] sm:text-[15px]">
            {product.name}
          </h3>
          <StarRating
            rating={product.rating}
            reviewCount={undefined}
            className="mt-0.5"
          />
          <p className="text-[11px] text-muted-foreground">
            {formatReviewCount(product.reviewCount)} reviews
          </p>
          <div className="mt-auto flex items-baseline gap-2 pt-2">
            <span className="text-base font-semibold text-[var(--ink)]">
              {formatINR(product.price)}
            </span>
            <span className="text-xs text-muted-foreground line-through">
              {formatINR(product.mrp)}
            </span>
            <span className="text-xs font-medium text-emerald-700">
              {product.discount}% off
            </span>
          </div>
        </div>
      </Link>

      <div className="px-3 pb-3 sm:px-3.5 sm:pb-3.5">
        <Button
          onClick={handleAdd}
          disabled={!product.inStock}
          className="h-10 w-full rounded-lg bg-[var(--ink)] text-sm font-medium text-white transition hover:bg-[var(--rose-deep)]"
        >
          <ShoppingBag className="size-4" />
          {product.inStock ? "Add to Bag" : "Out of Stock"}
        </Button>
      </div>
    </article>
  );
}
