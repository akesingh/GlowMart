"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Check, ChevronLeft } from "lucide-react";
import { products } from "@/data/products";
import { useCartStore } from "@/store/cart-store";
import { formatINR } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { CheckoutAddress, PaymentInfo } from "@/lib/types";

const steps = ["Bag", "Address", "Payment", "Review"] as const;

export function CheckoutFlow() {
  const router = useRouter();
  const items = useCartStore((s) => s.items);
  const clearCart = useCartStore((s) => s.clearCart);
  const [step, setStep] = useState(1);
  const [address, setAddress] = useState<CheckoutAddress>({
    fullName: "",
    email: "",
    phone: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [payment, setPayment] = useState<PaymentInfo>({ method: "card" });
  const [placing, setPlacing] = useState(false);

  const lines = useMemo(() => {
    return items
      .map((item) => {
        const product = products.find((p) => p.id === item.productId);
        if (!product) return null;
        return { ...item, product };
      })
      .filter(Boolean) as Array<{
      productId: string;
      quantity: number;
      shade?: string;
      size?: string;
      product: (typeof products)[number];
    }>;
  }, [items]);

  const subtotal = lines.reduce((s, l) => s + l.product.price * l.quantity, 0);
  const mrpTotal = lines.reduce((s, l) => s + l.product.mrp * l.quantity, 0);
  const shipping = subtotal >= 799 || subtotal === 0 ? 0 : 49;
  const total = subtotal + shipping;

  if (!items.length && step < 4) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <h1 className="font-heading text-3xl">Your bag is empty</h1>
        <p className="mt-2 text-muted-foreground">Add something beautiful before checking out.</p>
        <Link
          href="/products"
          className="mt-6 inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
        >
          Continue shopping
        </Link>
      </div>
    );
  }

  const validateAddress = () => {
    const required: (keyof CheckoutAddress)[] = [
      "fullName",
      "email",
      "phone",
      "line1",
      "city",
      "state",
      "pincode",
    ];
    for (const key of required) {
      if (!address[key]?.trim()) {
        toast.error("Please fill in all required address fields");
        return false;
      }
    }
    if (!address.email.includes("@")) {
      toast.error("Enter a valid email");
      return false;
    }
    return true;
  };

  const validatePayment = () => {
    if (payment.method === "card") {
      if (!payment.cardNumber || !payment.cardName || !payment.expiry || !payment.cvv) {
        toast.error("Please complete card details");
        return false;
      }
    }
    if (payment.method === "upi" && !payment.upiId) {
      toast.error("Enter your UPI ID");
      return false;
    }
    return true;
  };

  const placeOrder = async () => {
    setPlacing(true);
    await new Promise((r) => setTimeout(r, 900));
    clearCart();
    setPlacing(false);
    toast.success("Order placed successfully!", {
      description: "A confirmation has been sent to your email.",
    });
    router.push("/checkout/success");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <Link
        href="/cart"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-[var(--rose-deep)]"
      >
        <ChevronLeft className="size-4" /> Back to bag
      </Link>

      <h1 className="font-heading text-3xl text-[var(--ink)] sm:text-4xl">Checkout</h1>

      <ol className="mt-6 flex flex-wrap gap-2 sm:gap-3">
        {steps.map((label, i) => {
          const n = i;
          const done = step > n;
          const current = step === n;
          return (
            <li
              key={label}
              className={cn(
                "flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium sm:text-sm",
                current && "bg-[var(--blush-soft)] text-[var(--rose-deep)]",
                done && "text-emerald-700",
                !current && !done && "text-muted-foreground"
              )}
            >
              <span
                className={cn(
                  "flex size-5 items-center justify-center rounded-full text-[10px]",
                  current && "bg-[var(--rose)] text-white",
                  done && "bg-emerald-600 text-white",
                  !current && !done && "bg-stone-200"
                )}
              >
                {done ? <Check className="size-3" /> : n + 1}
              </span>
              {label}
            </li>
          );
        })}
      </ol>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-[var(--blush)] bg-white p-5 sm:p-6">
          {step === 1 && (
            <div>
              <h2 className="font-heading text-xl">Your bag</h2>
              <ul className="mt-4 divide-y divide-[var(--blush)]">
                {lines.map((l) => (
                  <li key={`${l.productId}-${l.shade}-${l.size}`} className="flex gap-3 py-4">
                    <div className="relative size-16 overflow-hidden rounded-lg bg-[var(--blush-soft)]">
                      <Image
                        src={l.product.images[0]}
                        alt=""
                        fill
                        className="object-cover"
                        sizes="64px"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{l.product.name}</p>
                      <p className="text-xs text-muted-foreground">Qty {l.quantity}</p>
                    </div>
                    <p className="text-sm font-semibold">
                      {formatINR(l.product.price * l.quantity)}
                    </p>
                  </li>
                ))}
              </ul>
              <Button
                onClick={() => setStep(2)}
                className="mt-4 h-11 w-full rounded-full bg-[var(--ink)] hover:bg-[var(--rose-deep)]"
              >
                Continue to address
              </Button>
            </div>
          )}

          {step === 2 && (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                if (validateAddress()) setStep(3);
              }}
            >
              <h2 className="font-heading text-xl">Shipping address</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Full name"
                  value={address.fullName}
                  onChange={(v) => setAddress({ ...address, fullName: v })}
                  required
                />
                <Field
                  label="Phone"
                  value={address.phone}
                  onChange={(v) => setAddress({ ...address, phone: v })}
                  required
                />
                <Field
                  label="Email"
                  type="email"
                  value={address.email}
                  onChange={(v) => setAddress({ ...address, email: v })}
                  className="sm:col-span-2"
                  required
                />
                <Field
                  label="Address line 1"
                  value={address.line1}
                  onChange={(v) => setAddress({ ...address, line1: v })}
                  className="sm:col-span-2"
                  required
                />
                <Field
                  label="Address line 2"
                  value={address.line2 || ""}
                  onChange={(v) => setAddress({ ...address, line2: v })}
                  className="sm:col-span-2"
                />
                <Field
                  label="City"
                  value={address.city}
                  onChange={(v) => setAddress({ ...address, city: v })}
                  required
                />
                <Field
                  label="State"
                  value={address.state}
                  onChange={(v) => setAddress({ ...address, state: v })}
                  required
                />
                <Field
                  label="PIN code"
                  value={address.pincode}
                  onChange={(v) => setAddress({ ...address, pincode: v })}
                  required
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(1)}
                  className="h-11 rounded-full"
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  className="h-11 flex-1 rounded-full bg-[var(--ink)] hover:bg-[var(--rose-deep)]"
                >
                  Continue to payment
                </Button>
              </div>
            </form>
          )}

          {step === 3 && (
            <div>
              <h2 className="font-heading text-xl">Payment method</h2>
              <div className="mt-4 grid gap-2">
                {(
                  [
                    ["card", "Credit / Debit Card"],
                    ["upi", "UPI"],
                    ["wallet", "GlowMart Wallet"],
                    ["cod", "Cash on Delivery"],
                  ] as const
                ).map(([value, label]) => (
                  <label
                    key={value}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 text-sm transition",
                      payment.method === value
                        ? "border-[var(--rose)] bg-[var(--blush-soft)]"
                        : "border-[var(--blush)] hover:border-[var(--rose)]/40"
                    )}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={payment.method === value}
                      onChange={() => setPayment({ ...payment, method: value })}
                      className="accent-[var(--rose)]"
                    />
                    {label}
                  </label>
                ))}
              </div>

              {payment.method === "card" && (
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <Field
                    label="Card number"
                    value={payment.cardNumber || ""}
                    onChange={(v) => setPayment({ ...payment, cardNumber: v })}
                    className="sm:col-span-2"
                    placeholder="XXXX XXXX XXXX XXXX"
                  />
                  <Field
                    label="Name on card"
                    value={payment.cardName || ""}
                    onChange={(v) => setPayment({ ...payment, cardName: v })}
                    className="sm:col-span-2"
                  />
                  <Field
                    label="Expiry"
                    value={payment.expiry || ""}
                    onChange={(v) => setPayment({ ...payment, expiry: v })}
                    placeholder="MM/YY"
                  />
                  <Field
                    label="CVV"
                    value={payment.cvv || ""}
                    onChange={(v) => setPayment({ ...payment, cvv: v })}
                    placeholder="•••"
                  />
                </div>
              )}

              {payment.method === "upi" && (
                <div className="mt-4">
                  <Field
                    label="UPI ID"
                    value={payment.upiId || ""}
                    onChange={(v) => setPayment({ ...payment, upiId: v })}
                    placeholder="name@upi"
                  />
                </div>
              )}

              <div className="mt-5 flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(2)}
                  className="h-11 rounded-full"
                >
                  Back
                </Button>
                <Button
                  onClick={() => {
                    if (validatePayment()) setStep(4);
                  }}
                  className="h-11 flex-1 rounded-full bg-[var(--ink)] hover:bg-[var(--rose-deep)]"
                >
                  Review order
                </Button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div>
              <h2 className="font-heading text-xl">Review & place order</h2>
              <div className="mt-4 space-y-4 text-sm">
                <div className="rounded-xl bg-[var(--blush-soft)]/60 p-4">
                  <p className="font-medium">Deliver to</p>
                  <p className="mt-1 text-muted-foreground">
                    {address.fullName}, {address.line1}
                    {address.line2 ? `, ${address.line2}` : ""}, {address.city},{" "}
                    {address.state} {address.pincode}
                  </p>
                  <p className="text-muted-foreground">
                    {address.phone} · {address.email}
                  </p>
                </div>
                <div className="rounded-xl bg-[var(--blush-soft)]/60 p-4">
                  <p className="font-medium">Payment</p>
                  <p className="mt-1 capitalize text-muted-foreground">{payment.method}</p>
                </div>
                <ul className="divide-y divide-[var(--blush)] rounded-xl border border-[var(--blush)]">
                  {lines.map((l) => (
                    <li
                      key={`${l.productId}-${l.shade}-${l.size}`}
                      className="flex justify-between px-4 py-3"
                    >
                      <span>
                        {l.product.name} × {l.quantity}
                      </span>
                      <span className="font-medium">
                        {formatINR(l.product.price * l.quantity)}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-5 flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep(3)}
                  className="h-11 rounded-full"
                >
                  Back
                </Button>
                <Button
                  onClick={placeOrder}
                  disabled={placing}
                  className="h-11 flex-1 rounded-full bg-[var(--ink)] hover:bg-[var(--rose-deep)]"
                >
                  {placing ? "Placing order..." : `Pay ${formatINR(total)}`}
                </Button>
              </div>
            </div>
          )}
        </div>

        <div className="h-fit rounded-2xl border border-[var(--blush)] bg-white p-5 sm:p-6">
          <h2 className="font-heading text-xl">Summary</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Subtotal</dt>
              <dd>{formatINR(subtotal)}</dd>
            </div>
            <div className="flex justify-between text-emerald-700">
              <dt>You save</dt>
              <dd>-{formatINR(mrpTotal - subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Shipping</dt>
              <dd>{shipping === 0 ? "FREE" : formatINR(shipping)}</dd>
            </div>
            <div className="flex justify-between border-t border-[var(--blush)] pt-3 text-base font-semibold">
              <dt>Total</dt>
              <dd>{formatINR(total)}</dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  className,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  className?: string;
  placeholder?: string;
}) {
  return (
    <label className={cn("block text-sm", className)}>
      <span className="mb-1.5 block text-muted-foreground">
        {label}
        {required && " *"}
      </span>
      <Input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 rounded-xl border-[var(--blush)]"
      />
    </label>
  );
}
