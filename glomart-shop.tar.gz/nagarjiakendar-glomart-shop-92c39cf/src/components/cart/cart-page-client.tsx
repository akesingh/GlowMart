"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { products } from "@/data/products";
import { useCartStore } from "@/store/cart-store";
import { CartItemRow } from "@/components/cart/cart-item";
import { CartSummary } from "@/components/cart/cart-summary";
import { ShoppingBag } from "lucide-react";

export function CartPageClient() {
  const items = useCartStore((s) => s.items);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);

  const lines = useMemo(() => {
    return items
      .map((item) => {
        const product = products.find((p) => p.id === item.productId);
        if (!product) return null;
        return { ...item, product };
      })
      .filter(Boolean) as Array<{
      productId: string;
      quantity: number;
      shade?: string;
      size?: string;
      product: (typeof products)[number];
    }>;
  }, [items]);

  const subtotal = lines.reduce((s, l) => s + l.product.price * l.quantity, 0);
  const mrpTotal = lines.reduce((s, l) => s + l.product.mrp * l.quantity, 0);
  const itemCount = lines.reduce((s, l) => s + l.quantity, 0);

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="h-8 w-40 animate-pulse rounded bg-[var(--blush-soft)]" />
        <div className="mt-8 h-64 animate-pulse rounded-2xl bg-[var(--blush-soft)]" />
      </div>
    );
  }

  if (!lines.length) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-20 text-center">
        <span className="flex size-16 items-center justify-center rounded-full bg-[var(--blush-soft)] text-[var(--rose-deep)]">
          <ShoppingBag className="size-7" />
        </span>
        <h1 className="font-heading mt-5 text-3xl text-[var(--ink)]">Your bag is empty</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Discover makeup, skincare, and more — your glow awaits.
        </p>
        <Link
          href="/products"
          className="mt-6 inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
        >
          Start shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <h1 className="font-heading text-3xl text-[var(--ink)] sm:text-4xl">
        Shopping bag
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {itemCount} {itemCount === 1 ? "item" : "items"}
      </p>
      <div className="mt-8 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <div className="rounded-2xl border border-[var(--blush)] bg-white px-4 sm:px-5">
          {lines.map((l) => (
            <CartItemRow
              key={`${l.productId}-${l.shade}-${l.size}`}
              product={l.product}
              quantity={l.quantity}
              shade={l.shade}
              size={l.size}
            />
          ))}
        </div>
        <CartSummary subtotal={subtotal} mrpTotal={mrpTotal} itemCount={itemCount} />
      </div>
    </div>
  );
}
