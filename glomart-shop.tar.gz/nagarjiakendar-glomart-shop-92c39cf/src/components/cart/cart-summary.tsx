"use client";

import Link from "next/link";
import { formatINR } from "@/lib/format";

interface CartSummaryProps {
  subtotal: number;
  mrpTotal: number;
  itemCount: number;
  showCheckout?: boolean;
}

export function CartSummary({
  subtotal,
  mrpTotal,
  itemCount,
  showCheckout = true,
}: CartSummaryProps) {
  const discount = mrpTotal - subtotal;
  const shipping = subtotal >= 799 || subtotal === 0 ? 0 : 49;
  const total = subtotal + shipping;

  return (
    <div className="rounded-2xl border border-[var(--blush)] bg-white p-5 sm:p-6">
      <h2 className="font-heading text-xl text-[var(--ink)]">Order summary</h2>
      <dl className="mt-4 space-y-3 text-sm">
        <div className="flex justify-between">
          <dt className="text-muted-foreground">
            Bag total ({itemCount} {itemCount === 1 ? "item" : "items"})
          </dt>
          <dd>{formatINR(mrpTotal)}</dd>
        </div>
        <div className="flex justify-between text-emerald-700">
          <dt>Product discount</dt>
          <dd>-{formatINR(discount)}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-muted-foreground">Shipping</dt>
          <dd>{shipping === 0 ? "FREE" : formatINR(shipping)}</dd>
        </div>
        {subtotal > 0 && subtotal < 799 && (
          <p className="text-xs text-[var(--rose-deep)]">
            Add {formatINR(799 - subtotal)} more for free shipping
          </p>
        )}
        <div className="flex justify-between border-t border-[var(--blush)] pt-3 text-base font-semibold">
          <dt>Total</dt>
          <dd>{formatINR(total)}</dd>
        </div>
      </dl>
      {showCheckout && (
        itemCount === 0 ? (
          <button
            type="button"
            disabled
            className="mt-5 flex h-12 w-full items-center justify-center rounded-full bg-[var(--ink)] text-sm font-medium text-white opacity-50"
          >
            Proceed to Checkout
          </button>
        ) : (
          <Link
            href="/checkout"
            className="mt-5 flex h-12 w-full items-center justify-center rounded-full bg-[var(--ink)] text-sm font-medium text-white transition hover:bg-[var(--rose-deep)]"
          >
            Proceed to Checkout
          </Link>
        )
      )}
    </div>
  );
}
