"use client";

import Image from "next/image";
import Link from "next/link";
import { Minus, Plus, Trash2 } from "lucide-react";
import type { Product } from "@/lib/types";
import { formatINR } from "@/lib/format";
import { useCartStore } from "@/store/cart-store";

interface CartItemRowProps {
  product: Product;
  quantity: number;
  shade?: string;
  size?: string;
}

export function CartItemRow({ product, quantity, shade, size }: CartItemRowProps) {
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeItem = useCartStore((s) => s.removeItem);

  return (
    <div className="flex gap-4 border-b border-[var(--blush)] py-5 last:border-0">
      <Link
        href={`/products/${product.slug}`}
        className="relative size-24 shrink-0 overflow-hidden rounded-xl bg-[var(--blush-soft)] sm:size-28"
      >
        <Image src={product.images[0]} alt={product.name} fill className="object-cover" sizes="112px" />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[11px] font-semibold tracking-wider text-[var(--rose-deep)] uppercase">
              {product.brand}
            </p>
            <Link
              href={`/products/${product.slug}`}
              className="mt-0.5 line-clamp-2 text-sm font-medium text-[var(--ink)] hover:text-[var(--rose-deep)]"
            >
              {product.name}
            </Link>
            {(shade || size) && (
              <p className="mt-1 text-xs text-muted-foreground">
                {[shade, size].filter(Boolean).join(" · ")}
              </p>
            )}
          </div>
          <button
            type="button"
            aria-label="Remove item"
            onClick={() => removeItem(product.id, shade, size)}
            className="rounded-full p-2 text-muted-foreground transition hover:bg-[var(--blush-soft)] hover:text-[var(--rose-deep)]"
          >
            <Trash2 className="size-4" />
          </button>
        </div>
        <div className="mt-auto flex items-center justify-between pt-3">
          <div className="flex h-9 items-center rounded-full border border-[var(--blush)]">
            <button
              type="button"
              aria-label="Decrease"
              onClick={() => updateQuantity(product.id, quantity - 1, shade, size)}
              className="flex size-9 items-center justify-center"
            >
              <Minus className="size-3.5" />
            </button>
            <span className="w-7 text-center text-sm">{quantity}</span>
            <button
              type="button"
              aria-label="Increase"
              onClick={() => updateQuantity(product.id, quantity + 1, shade, size)}
              className="flex size-9 items-center justify-center"
            >
              <Plus className="size-3.5" />
            </button>
          </div>
          <div className="text-right">
            <p className="font-semibold">{formatINR(product.price * quantity)}</p>
            <p className="text-xs text-muted-foreground line-through">
              {formatINR(product.mrp * quantity)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
