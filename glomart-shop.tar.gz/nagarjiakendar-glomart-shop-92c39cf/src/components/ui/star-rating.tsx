import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  rating: number;
  size?: "sm" | "md";
  showValue?: boolean;
  reviewCount?: number;
  className?: string;
}

export function StarRating({
  rating,
  size = "sm",
  showValue = true,
  reviewCount,
  className,
}: StarRatingProps) {
  const iconSize = size === "sm" ? "size-3.5" : "size-4";

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div className="flex items-center gap-0.5" aria-hidden>
        {Array.from({ length: 5 }).map((_, i) => {
          const filled = rating >= i + 1;
          const partial = !filled && rating > i;
          return (
            <Star
              key={i}
              className={cn(
                iconSize,
                filled
                  ? "fill-amber-400 text-amber-400"
                  : partial
                    ? "fill-amber-400/50 text-amber-400"
                    : "fill-transparent text-stone-300"
              )}
            />
          );
        })}
      </div>
      {showValue && (
        <span className="text-xs font-medium text-foreground/80">
          {rating.toFixed(1)}
          {reviewCount !== undefined && (
            <span className="ml-1 font-normal text-muted-foreground">
              ({reviewCount.toLocaleString("en-IN")})
            </span>
          )}
        </span>
      )}
    </div>
  );
}
