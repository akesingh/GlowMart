"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Search, X, TrendingUp, Tag, Package } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  getSearchSuggestions,
  type SearchSuggestion,
} from "@/services/search-service";
import { cn } from "@/lib/utils";

interface SearchAutocompleteProps {
  className?: string;
  compact?: boolean;
  onNavigate?: () => void;
}

export function SearchAutocomplete({
  className,
  compact,
  onNavigate,
}: SearchAutocompleteProps) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [isPending, startTransition] = useTransition();
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      startTransition(async () => {
        const results = await getSearchSuggestions(query);
        setSuggestions(results);
      });
    }, 180);
    return () => clearTimeout(timer);
  }, [query]);

  const submit = (value?: string) => {
    const q = (value ?? query).trim();
    if (!q) return;
    setOpen(false);
    onNavigate?.();
    router.push(`/search?q=${encodeURIComponent(q)}`);
  };

  const iconFor = (type: SearchSuggestion["type"]) => {
    if (type === "brand" || type === "category") return Tag;
    if (type === "product") return Package;
    return TrendingUp;
  };

  return (
    <div ref={containerRef} className={cn("relative w-full", className)}>
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="relative"
      >
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder={compact ? "Search products" : "Search for lipstick, serum, perfume..."}
          aria-label="Search products"
          aria-expanded={open}
          aria-controls="search-suggestions"
          className={cn(
            "h-11 rounded-full border-[var(--blush)] bg-[var(--blush-soft)]/60 pr-10 pl-10 text-sm shadow-none transition focus-visible:border-[var(--rose)] focus-visible:ring-[var(--rose)]/20",
            compact && "h-10"
          )}
        />
        {query && (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => {
              setQuery("");
              inputRef.current?.focus();
            }}
            className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        )}
      </form>

      {open && (
        <div
          id="search-suggestions"
          role="listbox"
          className="absolute z-50 mt-2 w-full overflow-hidden rounded-2xl border border-[var(--blush)] bg-white shadow-[0_20px_50px_-20px_rgba(42,31,34,0.25)]"
        >
          <div className="max-h-[70vh] overflow-y-auto p-2">
            {!query && (
              <p className="px-3 py-2 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
                Popular searches
              </p>
            )}
            {isPending && !suggestions.length ? (
              <p className="px-3 py-4 text-sm text-muted-foreground">Searching...</p>
            ) : suggestions.length === 0 ? (
              <p className="px-3 py-4 text-sm text-muted-foreground">No matches found</p>
            ) : (
              suggestions.map((s, i) => {
                const Icon = iconFor(s.type);
                return (
                  <Link
                    key={`${s.type}-${s.label}-${i}`}
                    href={s.href}
                    role="option"
                    onClick={() => {
                      setOpen(false);
                      onNavigate?.();
                    }}
                    className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition hover:bg-[var(--blush-soft)]"
                  >
                    {s.image ? (
                      <div className="relative size-10 overflow-hidden rounded-lg bg-[var(--blush-soft)]">
                        <Image src={s.image} alt="" fill className="object-cover" sizes="40px" />
                      </div>
                    ) : (
                      <span className="flex size-10 items-center justify-center rounded-lg bg-[var(--blush-soft)] text-[var(--rose-deep)]">
                        <Icon className="size-4" />
                      </span>
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium text-[var(--ink)]">
                        {s.label}
                      </span>
                      {s.meta && (
                        <span className="text-xs text-muted-foreground">{s.meta}</span>
                      )}
                    </span>
                  </Link>
                );
              })
            )}
            {query.trim() && (
              <button
                type="button"
                onClick={() => submit()}
                className="mt-1 flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium text-[var(--rose-deep)] hover:bg-[var(--blush-soft)]"
              >
                <Search className="size-4" />
                Search for &ldquo;{query.trim()}&rdquo;
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
