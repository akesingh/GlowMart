"use client";

import Link from "next/link";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { megaMenuData } from "@/data/categories";
import { cn } from "@/lib/utils";

export function MegaMenu() {
  const [active, setActive] = useState<string | null>(null);

  return (
    <nav
      className="relative hidden border-t border-[var(--blush)]/70 bg-white lg:block"
      aria-label="Product categories"
      onMouseLeave={() => setActive(null)}
    >
      <ul className="mx-auto flex max-w-7xl items-center justify-center gap-1 px-4">
        {megaMenuData.map((cat) => (
          <li
            key={cat.id}
            className="relative"
            onMouseEnter={() => setActive(cat.slug)}
          >
            <Link
              href={`/products?category=${cat.slug}`}
              className={cn(
                "flex items-center gap-1 px-3 py-3.5 text-[13px] font-medium tracking-wide text-[var(--ink)] transition hover:text-[var(--rose-deep)]",
                active === cat.slug && "text-[var(--rose-deep)]"
              )}
            >
              {cat.name}
              <ChevronDown
                className={cn(
                  "size-3.5 opacity-50 transition",
                  active === cat.slug && "rotate-180 opacity-100"
                )}
              />
            </Link>

            <div
              className={cn(
                "absolute top-full left-1/2 z-40 w-[min(720px,80vw)] -translate-x-1/2 overflow-hidden rounded-b-2xl border border-t-0 border-[var(--blush)] bg-white shadow-[0_24px_60px_-24px_rgba(42,31,34,0.28)] transition-all duration-200",
                active === cat.slug
                  ? "pointer-events-auto translate-y-0 opacity-100"
                  : "pointer-events-none -translate-y-1 opacity-0"
              )}
            >
              <div className="grid grid-cols-[1.2fr_1fr] gap-0">
                <div className="p-6">
                  <p className="mb-3 text-[11px] font-semibold tracking-[0.14em] text-[var(--rose-deep)] uppercase">
                    Shop by type
                  </p>
                  <ul className="grid grid-cols-2 gap-x-4 gap-y-2">
                    {cat.subcategories.map((sub) => (
                      <li key={sub}>
                        <Link
                          href={`/products?category=${cat.slug}&sub=${encodeURIComponent(sub)}`}
                          className="block rounded-lg px-2 py-1.5 text-sm text-[var(--ink)]/80 transition hover:bg-[var(--blush-soft)] hover:text-[var(--rose-deep)]"
                        >
                          {sub}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
                <div
                  className="flex flex-col justify-between p-6"
                  style={{ backgroundColor: cat.accent }}
                >
                  <div>
                    <p className="font-heading text-2xl text-[var(--ink)]">{cat.name}</p>
                    <p className="mt-2 text-sm text-[var(--ink)]/70">{cat.description}</p>
                  </div>
                  <div className="mt-6 space-y-2">
                    {cat.featured.map((f) => (
                      <Link
                        key={f}
                        href={`/products?category=${cat.slug}`}
                        className="block text-sm font-medium text-[var(--rose-deep)] underline-offset-4 hover:underline"
                      >
                        {f} →
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
        <li>
          <Link
            href="/products?sort=discount"
            className="px-3 py-3.5 text-[13px] font-semibold tracking-wide text-[var(--rose)] transition hover:text-[var(--rose-deep)]"
          >
            Deals
          </Link>
        </li>
      </ul>
    </nav>
  );
}
