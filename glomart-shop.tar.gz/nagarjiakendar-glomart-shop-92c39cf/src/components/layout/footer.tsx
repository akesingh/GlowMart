import Link from "next/link";
import { Share2 } from "lucide-react";
import { categories } from "@/data/categories";

const helpLinks = [
  { label: "Contact Us", href: "/help/contact" },
  { label: "FAQs", href: "/help/faq" },
  { label: "Shipping & Delivery", href: "/help/shipping" },
  { label: "Returns & Refunds", href: "/help/returns" },
  { label: "Track Order", href: "/help/track" },
];

const aboutLinks = [
  { label: "About GlowMart", href: "/about" },
  { label: "Careers", href: "/careers" },
  { label: "Press", href: "/press" },
  { label: "Beauty Blog", href: "/blog" },
  { label: "Store Locator", href: "/stores" },
];

const socials = ["Instagram", "Facebook", "YouTube", "X"];

export function Footer() {
  return (
    <footer className="mt-auto border-t border-[var(--blush)] bg-[var(--ink)] text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-heading text-3xl tracking-tight">
            Glow<span className="text-[var(--blush)]">Mart</span>
          </p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-white/65">
            Your curated beauty destination for makeup, skincare, haircare, and fragrance —
            elevated essentials with everyday ease.
          </p>
          <div className="mt-5 flex gap-3">
            {socials.map((name) => (
              <a
                key={name}
                href="#"
                aria-label={name}
                className="flex size-9 items-center justify-center rounded-full bg-white/10 text-white/80 transition hover:bg-[var(--rose)] hover:text-white"
              >
                <Share2 className="size-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold tracking-[0.16em] text-[var(--blush)] uppercase">
            Categories
          </p>
          <ul className="mt-4 space-y-2.5">
            {categories.map((c) => (
              <li key={c.id}>
                <Link
                  href={`/products?category=${c.slug}`}
                  className="text-sm text-white/70 transition hover:text-white"
                >
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-xs font-semibold tracking-[0.16em] text-[var(--blush)] uppercase">
            Help
          </p>
          <ul className="mt-4 space-y-2.5">
            {helpLinks.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="text-sm text-white/70 transition hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-xs font-semibold tracking-[0.16em] text-[var(--blush)] uppercase">
            About
          </p>
          <ul className="mt-4 space-y-2.5">
            {aboutLinks.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="text-sm text-white/70 transition hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-5 text-xs text-white/50 sm:flex-row">
          <p>© {new Date().getFullYear()} GlowMart. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-white/80">
              Privacy
            </Link>
            <Link href="/terms" className="hover:text-white/80">
              Terms
            </Link>
            <Link href="/cookies" className="hover:text-white/80">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
