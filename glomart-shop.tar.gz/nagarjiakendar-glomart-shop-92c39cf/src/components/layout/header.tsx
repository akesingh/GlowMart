"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Heart, Menu, ShoppingBag, User, X } from "lucide-react";
import { SearchAutocomplete } from "@/components/layout/search-autocomplete";
import { MegaMenu } from "@/components/layout/mega-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { categories } from "@/data/categories";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { cn } from "@/lib/utils";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const cartCount = useCartStore((s) => s.items.reduce((n, i) => n + i.quantity, 0));
  const wishlistCount = useWishlistStore((s) => s.productIds.length);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 bg-white/95 backdrop-blur-md transition-shadow",
        scrolled && "shadow-[0_8px_30px_-12px_rgba(42,31,34,0.15)]"
      )}
    >
      <div className="bg-[var(--ink)] px-4 py-1.5 text-center text-[11px] tracking-wide text-white/90 sm:text-xs">
        Free shipping on orders above ₹799 · Easy 7-day returns
      </div>

      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 lg:gap-6 lg:py-4">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger
            className="inline-flex size-10 items-center justify-center rounded-full hover:bg-[var(--blush-soft)] lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="size-5" />
          </SheetTrigger>
          <SheetContent side="left" className="w-[min(100%,340px)] p-0">
            <SheetHeader className="border-b border-[var(--blush)] px-4 py-4">
              <SheetTitle className="font-heading text-left text-2xl">
                Glow<span className="text-[var(--rose)]">Mart</span>
              </SheetTitle>
            </SheetHeader>
            <div className="space-y-1 p-3">
              <p className="px-3 py-2 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
                Categories
              </p>
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/products?category=${c.slug}`}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between rounded-xl px-3 py-3 text-sm font-medium hover:bg-[var(--blush-soft)]"
                >
                  {c.name}
                  <span className="text-xs text-muted-foreground">
                    {c.subcategories.length}
                  </span>
                </Link>
              ))}
              <Link
                href="/products?sort=discount"
                onClick={() => setMobileOpen(false)}
                className="flex rounded-xl px-3 py-3 text-sm font-semibold text-[var(--rose)] hover:bg-[var(--blush-soft)]"
              >
                Deals of the day
              </Link>
            </div>
          </SheetContent>
        </Sheet>

        <Link href="/" className="shrink-0">
          <span className="font-heading text-[1.65rem] leading-none tracking-tight text-[var(--ink)] sm:text-3xl">
            Glow<span className="text-[var(--rose)]">Mart</span>
          </span>
        </Link>

        <div className="mx-auto hidden max-w-xl flex-1 md:block">
          <SearchAutocomplete />
        </div>

        <div className="ml-auto flex items-center gap-0.5 sm:gap-1">
          <Link
            href="/account"
            className="hidden size-10 items-center justify-center rounded-full text-[var(--ink)] transition hover:bg-[var(--blush-soft)] sm:inline-flex"
            aria-label="Account"
          >
            <User className="size-5" />
          </Link>
          <Link
            href="/wishlist"
            className="relative inline-flex size-10 items-center justify-center rounded-full text-[var(--ink)] transition hover:bg-[var(--blush-soft)]"
            aria-label="Wishlist"
          >
            <Heart className="size-5" />
            {hydrated && wishlistCount > 0 && (
              <span className="absolute top-1 right-1 flex size-4 items-center justify-center rounded-full bg-[var(--rose)] text-[9px] font-bold text-white">
                {wishlistCount > 9 ? "9+" : wishlistCount}
              </span>
            )}
          </Link>
          <Link
            href="/cart"
            className="relative inline-flex size-10 items-center justify-center rounded-full text-[var(--ink)] transition hover:bg-[var(--blush-soft)]"
            aria-label="Shopping bag"
          >
            <ShoppingBag className="size-5" />
            {hydrated && cartCount > 0 && (
              <span className="absolute top-1 right-1 flex size-4 items-center justify-center rounded-full bg-[var(--rose)] text-[9px] font-bold text-white">
                {cartCount > 9 ? "9+" : cartCount}
              </span>
            )}
          </Link>
        </div>
      </div>

      <div className="border-t border-[var(--blush)]/50 px-4 py-2.5 md:hidden">
        <SearchAutocomplete compact />
      </div>

      <MegaMenu />
    </header>
  );
}
