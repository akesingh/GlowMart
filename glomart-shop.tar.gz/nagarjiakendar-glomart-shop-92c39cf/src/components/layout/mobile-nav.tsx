"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart, Home, Search, ShoppingBag, Grid3X3 } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";

const items = [
  { href: "/", label: "Home", icon: Home },
  { href: "/products", label: "Shop", icon: Grid3X3 },
  { href: "/search", label: "Search", icon: Search },
  { href: "/wishlist", label: "Wishlist", icon: Heart },
  { href: "/cart", label: "Bag", icon: ShoppingBag },
];

export function MobileNav() {
  const pathname = usePathname();
  const cartCount = useCartStore((s) => s.items.reduce((n, i) => n + i.quantity, 0));
  const wishlistCount = useWishlistStore((s) => s.productIds.length);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-[var(--blush)] bg-white/95 backdrop-blur-md lg:hidden"
      aria-label="Mobile navigation"
    >
      <ul className="mx-auto flex max-w-lg items-stretch justify-between px-2 pb-[env(safe-area-inset-bottom)]">
        {items.map(({ href, label, icon: Icon }) => {
          const active =
            href === "/"
              ? pathname === "/"
              : pathname === href || pathname.startsWith(`${href}/`);
          const count =
            href === "/cart" ? cartCount : href === "/wishlist" ? wishlistCount : 0;
          return (
            <li key={href} className="flex-1">
              <Link
                href={href}
                className={cn(
                  "relative flex flex-col items-center gap-0.5 px-1 py-2.5 text-[10px] font-medium transition",
                  active ? "text-[var(--rose-deep)]" : "text-muted-foreground"
                )}
              >
                <span className="relative">
                  <Icon className={cn("size-5", active && "stroke-[2.25]")} />
                  {hydrated && count > 0 && (
                    <span className="absolute -top-1.5 -right-2 flex size-3.5 items-center justify-center rounded-full bg-[var(--rose)] text-[8px] font-bold text-white">
                      {count > 9 ? "9+" : count}
                    </span>
                  )}
                </span>
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
