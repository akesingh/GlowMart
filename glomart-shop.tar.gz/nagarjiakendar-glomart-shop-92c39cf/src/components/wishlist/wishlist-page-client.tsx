"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Heart } from "lucide-react";
import { products } from "@/data/products";
import { useWishlistStore } from "@/store/wishlist-store";
import { ProductGrid } from "@/components/product/product-grid";

export function WishlistPageClient() {
  const productIds = useWishlistStore((s) => s.productIds);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);

  const list = useMemo(
    () => products.filter((p) => productIds.includes(p.id)),
    [productIds]
  );

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="h-8 w-48 animate-pulse rounded bg-[var(--blush-soft)]" />
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="aspect-[3/4] animate-pulse rounded-xl bg-[var(--blush-soft)]" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <h1 className="font-heading text-3xl text-[var(--ink)] sm:text-4xl">Wishlist</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {list.length} {list.length === 1 ? "item" : "items"} saved
      </p>

      {list.length === 0 ? (
        <div className="mt-16 flex flex-col items-center text-center">
          <span className="flex size-16 items-center justify-center rounded-full bg-[var(--blush-soft)] text-[var(--rose)]">
            <Heart className="size-7" />
          </span>
          <h2 className="font-heading mt-5 text-2xl">No favorites yet</h2>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">
            Tap the heart on any product to save it here for later.
          </p>
          <Link
            href="/products"
            className="mt-6 inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
          >
            Browse products
          </Link>
        </div>
      ) : (
        <div className="mt-8">
          <ProductGrid products={list} />
        </div>
      )}
    </div>
  );
}
