import Link from "next/link";
import { ProductCard } from "@/components/product/product-card";
import type { Product } from "@/lib/types";
import { ChevronRight } from "lucide-react";

interface ProductCarouselProps {
  title: string;
  eyebrow?: string;
  products: Product[];
  href?: string;
  linkLabel?: string;
}

export function ProductCarousel({
  title,
  eyebrow,
  products,
  href = "/products",
  linkLabel = "View all",
}: ProductCarouselProps) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-10 sm:py-12">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          {eyebrow && (
            <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
              {eyebrow}
            </p>
          )}
          <h2 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">{title}</h2>
        </div>
        <Link
          href={href}
          className="inline-flex items-center gap-0.5 text-sm font-medium text-[var(--rose-deep)] underline-offset-4 hover:underline"
        >
          {linkLabel}
          <ChevronRight className="size-4" />
        </Link>
      </div>
      <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2 snap-x snap-mandatory scrollbar-thin sm:gap-4">
        {products.map((product) => (
          <div
            key={product.id}
            className="w-[46%] shrink-0 snap-start sm:w-[30%] md:w-[23%] lg:w-[18.5%]"
          >
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </section>
  );
}
