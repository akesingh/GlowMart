"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function Newsletter() {
  const [email, setEmail] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) {
      toast.error("Please enter a valid email");
      return;
    }
    toast.success("You're on the list", {
      description: "Expect glow tips and exclusive drops in your inbox.",
    });
    setEmail("");
  };

  return (
    <section className="relative overflow-hidden bg-[var(--blush-soft)]">
      <div className="pointer-events-none absolute -right-20 -top-20 size-64 rounded-full bg-[var(--blush)]/40 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -left-16 size-72 rounded-full bg-[var(--rose)]/10 blur-3xl" />
      <div className="relative mx-auto max-w-3xl px-4 py-16 text-center sm:py-20">
        <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
          Stay in the glow
        </p>
        <h2 className="font-heading mt-2 text-3xl text-[var(--ink)] sm:text-4xl">
          Beauty tips & early access
        </h2>
        <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
          Join the GlowMart newsletter for new arrivals, member-only deals, and expert routines.
        </p>
        <form
          onSubmit={submit}
          className="mx-auto mt-7 flex max-w-md flex-col gap-2 sm:flex-row"
        >
          <Input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address"
            aria-label="Email for newsletter"
            className="h-12 flex-1 rounded-full border-[var(--blush)] bg-white px-5"
          />
          <Button
            type="submit"
            className="h-12 rounded-full bg-[var(--ink)] px-7 hover:bg-[var(--rose-deep)]"
          >
            Subscribe
          </Button>
        </form>
      </div>
    </section>
  );
}
