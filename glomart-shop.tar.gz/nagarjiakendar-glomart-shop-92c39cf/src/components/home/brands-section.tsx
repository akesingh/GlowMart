import Link from "next/link";
import Image from "next/image";
import { getFeaturedBrands } from "@/services/product-service";

export function BrandsSection() {
  const brands = getFeaturedBrands();

  return (
    <section className="border-y border-[var(--blush)] bg-[var(--blush-soft)]/50 py-14">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mb-8 text-center">
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
            Partners
          </p>
          <h2 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">
            Featured brands
          </h2>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {brands.map((brand) => (
            <Link
              key={brand.id}
              href={`/products?brand=${brand.slug}`}
              className="group flex aspect-[5/3] items-center justify-center rounded-xl bg-white p-3 transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <div className="relative h-full w-full">
                <Image
                  src={brand.logo}
                  alt={brand.name}
                  fill
                  className="object-contain opacity-90 transition group-hover:opacity-100"
                  sizes="120px"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
