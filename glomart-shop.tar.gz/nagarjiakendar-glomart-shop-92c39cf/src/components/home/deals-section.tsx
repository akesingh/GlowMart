import Link from "next/link";
import Image from "next/image";
import type { Product } from "@/lib/types";
import { formatINR } from "@/lib/format";
interface DealsSectionProps {
  products: Product[];
}

export function DealsSection({ products }: DealsSectionProps) {
  const featured = products[0];
  const rest = products.slice(1, 5);
  if (!featured) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-12">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
            Limited time
          </p>
          <h2 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">
            Deals of the day
          </h2>
        </div>
        <Link
          href="/products?sort=discount"
          className="text-sm font-medium text-[var(--rose-deep)] underline-offset-4 hover:underline"
        >
          All deals
        </Link>
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <Link
          href={`/products/${featured.slug}`}
          className="group relative overflow-hidden rounded-3xl bg-[var(--blush-soft)]"
        >
          <div className="grid min-h-[320px] sm:grid-cols-2">
            <div className="relative aspect-square sm:aspect-auto">
              <Image
                src={featured.images[0]}
                alt={featured.name}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 768px) 100vw, 40vw"
              />
            </div>
            <div className="flex flex-col justify-center p-6 sm:p-8">
              <span className="w-fit rounded-md bg-[var(--rose)] px-2 py-0.5 text-[10px] font-bold tracking-wide text-white uppercase">
                {featured.discount}% off
              </span>
              <p className="mt-3 text-xs font-semibold tracking-wider text-[var(--rose-deep)] uppercase">
                {featured.brand}
              </p>
              <h3 className="font-heading mt-1 text-2xl text-[var(--ink)] sm:text-3xl">
                {featured.name}
              </h3>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-xl font-semibold">{formatINR(featured.price)}</span>
                <span className="text-sm text-muted-foreground line-through">
                  {formatINR(featured.mrp)}
                </span>
              </div>
              <span className="mt-6 inline-flex h-10 w-fit items-center rounded-full bg-[var(--ink)] px-5 text-sm font-medium text-white transition group-hover:bg-[var(--rose-deep)]">
                Grab deal
              </span>
            </div>
          </div>
        </Link>
        <div className="grid grid-cols-2 gap-3">
          {rest.map((p) => (
            <Link
              key={p.id}
              href={`/products/${p.slug}`}
              className="group overflow-hidden rounded-2xl bg-white ring-1 ring-[var(--blush)] transition hover:shadow-md"
            >
              <div className="relative aspect-square overflow-hidden bg-[var(--blush-soft)]">
                <Image
                  src={p.images[0]}
                  alt={p.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="20vw"
                />
                <span className="absolute top-2 left-2 rounded-md bg-amber-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                  {p.discount}% off
                </span>
              </div>
              <div className="p-3">
                <p className="truncate text-xs text-muted-foreground">{p.brand}</p>
                <p className="mt-0.5 line-clamp-1 text-sm font-medium">{p.name}</p>
                <p className="mt-1 text-sm font-semibold">{formatINR(p.price)}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
