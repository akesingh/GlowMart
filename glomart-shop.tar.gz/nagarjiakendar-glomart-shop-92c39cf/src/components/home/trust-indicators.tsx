import { ShieldCheck, Truck, RotateCcw, BadgeCheck } from "lucide-react";

const items = [
  {
    icon: Truck,
    title: "Free shipping",
    text: "On orders above ₹799 across India",
  },
  {
    icon: RotateCcw,
    title: "Easy returns",
    text: "Hassle-free 7-day return window",
  },
  {
    icon: ShieldCheck,
    title: "100% authentic",
    text: "Sourced directly from brand partners",
  },
  {
    icon: BadgeCheck,
    title: "Secure checkout",
    text: "Encrypted payments & buyer protection",
  },
];

export function TrustIndicators() {
  return (
    <section className="border-y border-[var(--blush)] bg-white py-10">
      <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:grid-cols-2 lg:grid-cols-4">
        {items.map(({ icon: Icon, title, text }) => (
          <div key={title} className="flex items-start gap-3">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-[var(--blush-soft)] text-[var(--rose-deep)]">
              <Icon className="size-5" />
            </span>
            <div>
              <p className="font-medium text-[var(--ink)]">{title}</p>
              <p className="mt-0.5 text-sm text-muted-foreground">{text}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
