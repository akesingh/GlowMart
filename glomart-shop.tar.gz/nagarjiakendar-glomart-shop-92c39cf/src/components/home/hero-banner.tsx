"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const slides = [
  {
    id: 1,
    title: "Glow into the season",
    subtitle: "Up to 40% off curated bestsellers across makeup & skincare",
    cta: "Shop bestsellers",
    href: "/products?sort=relevance",
    image: "/images/hero/hero-1.svg",
    tone: "rose",
  },
  {
    id: 2,
    title: "Skincare that delivers",
    subtitle: "Vitamin C, retinol & SPF — dermatologist-loved essentials",
    cta: "Explore skincare",
    href: "/products?category=skincare",
    image: "/images/hero/hero-2.svg",
    tone: "sage",
  },
  {
    id: 3,
    title: "Find your signature scent",
    subtitle: "Artisanal fragrances and discovery sets, ready to gift",
    cta: "Shop fragrance",
    href: "/products?category=fragrance",
    image: "/images/hero/hero-3.svg",
    tone: "lilac",
  },
];

export function HeroBanner() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length);
    }, 5500);
    return () => clearInterval(id);
  }, []);

  const slide = slides[index];

  return (
    <section className="relative overflow-hidden" aria-label="Promotional banners">
      <div className="relative mx-auto min-h-[340px] w-full max-w-7xl sm:min-h-[420px] lg:min-h-[520px]">
        {slides.map((s, i) => (
          <div
            key={s.id}
            className={cn(
              "absolute inset-0 transition-opacity duration-700",
              i === index
                ? "z-10 opacity-100"
                : "pointer-events-none z-0 opacity-0"
            )}
            aria-hidden={i !== index}
          >
            <Image
              src={s.image}
              alt=""
              fill
              priority={i === 0}
              className="object-cover"
              sizes="100vw"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-white/85 via-white/55 to-transparent" />
            <div className="relative flex h-full max-w-xl flex-col justify-center px-6 py-12 sm:px-10 lg:px-14">
              <p className="mb-3 text-[11px] font-semibold tracking-[0.2em] text-[var(--rose-deep)] uppercase animate-fade-up">
                GlowMart edit
              </p>
              <h1 className="font-heading text-4xl leading-[1.1] text-[var(--ink)] sm:text-5xl lg:text-6xl animate-fade-up-delay">
                {s.title}
              </h1>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-[var(--ink)]/70 sm:text-base animate-fade-up-delay-2">
                {s.subtitle}
              </p>
              <div className="mt-7 animate-fade-up-delay-2">
                <Link
                  href={s.href}
                  className="inline-flex h-12 items-center justify-center rounded-full bg-[var(--ink)] px-7 text-sm font-medium text-white transition hover:bg-[var(--rose-deep)]"
                >
                  {s.cta}
                </Link>
              </div>
            </div>
          </div>
        ))}

        <button
          type="button"
          aria-label="Previous slide"
          onClick={() => setIndex((i) => (i - 1 + slides.length) % slides.length)}
          className="absolute top-1/2 left-3 z-20 hidden size-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur sm:flex hover:bg-white"
        >
          <ChevronLeft className="size-5" />
        </button>
        <button
          type="button"
          aria-label="Next slide"
          onClick={() => setIndex((i) => (i + 1) % slides.length)}
          className="absolute top-1/2 right-3 z-20 hidden size-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur sm:flex hover:bg-white"
        >
          <ChevronRight className="size-5" />
        </button>

        <div className="absolute bottom-5 left-1/2 z-20 flex -translate-x-1/2 gap-2">
          {slides.map((s, i) => (
            <button
              key={s.id}
              type="button"
              aria-label={`Go to slide ${i + 1}`}
              aria-current={i === index}
              onClick={() => setIndex(i)}
              className={cn(
                "h-1.5 rounded-full transition-all",
                i === index ? "w-8 bg-[var(--rose)]" : "w-1.5 bg-[var(--ink)]/25"
              )}
            />
          ))}
        </div>
      </div>
      <span className="sr-only">{slide.title}</span>
    </section>
  );
}
