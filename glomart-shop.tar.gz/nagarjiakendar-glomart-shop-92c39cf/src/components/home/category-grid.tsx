import Link from "next/link";
import Image from "next/image";
import { categories } from "@/data/categories";

export function CategoryGrid() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
            Browse
          </p>
          <h2 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">
            Beauty categories
          </h2>
        </div>
        <Link
          href="/products"
          className="hidden text-sm font-medium text-[var(--rose-deep)] underline-offset-4 hover:underline sm:inline"
        >
          View all
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-7">
        {categories.map((cat, i) => (
          <Link
            key={cat.id}
            href={`/products?category=${cat.slug}`}
            className="group flex flex-col items-center text-center animate-fade-up"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div
              className="relative mb-3 aspect-square w-full overflow-hidden rounded-2xl transition-transform duration-300 group-hover:-translate-y-1 group-hover:shadow-[0_16px_40px_-16px_rgba(92,42,50,0.25)]"
              style={{ backgroundColor: cat.accent }}
            >
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 640px) 45vw, 12vw"
              />
            </div>
            <span className="text-sm font-medium text-[var(--ink)] group-hover:text-[var(--rose-deep)]">
              {cat.name}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
