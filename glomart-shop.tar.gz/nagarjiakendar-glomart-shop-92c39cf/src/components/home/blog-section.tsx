import Link from "next/link";
import Image from "next/image";
import { getBlogPosts } from "@/services/product-service";

export function BlogSection() {
  const posts = getBlogPosts();

  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
            GlowMart Journal
          </p>
          <h2 className="font-heading mt-1 text-3xl text-[var(--ink)] sm:text-4xl">
            Beauty content
          </h2>
        </div>
        <Link
          href="/blog"
          className="text-sm font-medium text-[var(--rose-deep)] underline-offset-4 hover:underline"
        >
          Read more
        </Link>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/blog/${post.slug}`}
            className="group overflow-hidden rounded-2xl bg-white transition hover:-translate-y-1 hover:shadow-[0_16px_40px_-16px_rgba(92,42,50,0.2)]"
          >
            <div className="relative aspect-[16/10] overflow-hidden">
              <Image
                src={post.image}
                alt=""
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
                sizes="(max-width: 768px) 100vw, 25vw"
              />
            </div>
            <div className="p-4">
              <p className="text-[11px] font-semibold tracking-wider text-[var(--rose-deep)] uppercase">
                {post.category} · {post.readTime}
              </p>
              <h3 className="mt-2 line-clamp-2 font-heading text-xl leading-snug text-[var(--ink)]">
                {post.title}
              </h3>
              <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{post.excerpt}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
