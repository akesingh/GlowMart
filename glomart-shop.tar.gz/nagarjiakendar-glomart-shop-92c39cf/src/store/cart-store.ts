"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartItem } from "@/lib/types";

interface CartState {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (productId: string, shade?: string, size?: string) => void;
  updateQuantity: (productId: string, quantity: number, shade?: string, size?: string) => void;
  clearCart: () => void;
  getCount: () => number;
}

function sameLine(a: CartItem, productId: string, shade?: string, size?: string) {
  return a.productId === productId && a.shade === shade && a.size === size;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) => {
        set((state) => {
          const existing = state.items.find((i) =>
            sameLine(i, item.productId, item.shade, item.size)
          );
          if (existing) {
            return {
              items: state.items.map((i) =>
                sameLine(i, item.productId, item.shade, item.size)
                  ? { ...i, quantity: i.quantity + item.quantity }
                  : i
              ),
            };
          }
          return { items: [...state.items, item] };
        });
      },
      removeItem: (productId, shade, size) => {
        set((state) => ({
          items: state.items.filter((i) => !sameLine(i, productId, shade, size)),
        }));
      },
      updateQuantity: (productId, quantity, shade, size) => {
        if (quantity <= 0) {
          get().removeItem(productId, shade, size);
          return;
        }
        set((state) => ({
          items: state.items.map((i) =>
            sameLine(i, productId, shade, size) ? { ...i, quantity } : i
          ),
        }));
      },
      clearCart: () => set({ items: [] }),
      getCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: "glowmart-cart" }
  )
);
