"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

interface WishlistState {
  productIds: string[];
  toggle: (productId: string) => boolean;
  add: (productId: string) => void;
  remove: (productId: string) => void;
  has: (productId: string) => boolean;
  clear: () => void;
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      productIds: [],
      toggle: (productId) => {
        const exists = get().productIds.includes(productId);
        if (exists) {
          set((s) => ({
            productIds: s.productIds.filter((id) => id !== productId),
          }));
          return false;
        }
        set((s) => ({ productIds: [...s.productIds, productId] }));
        return true;
      },
      add: (productId) => {
        if (!get().productIds.includes(productId)) {
          set((s) => ({ productIds: [...s.productIds, productId] }));
        }
      },
      remove: (productId) => {
        set((s) => ({
          productIds: s.productIds.filter((id) => id !== productId),
        }));
      },
      has: (productId) => get().productIds.includes(productId),
      clear: () => set({ productIds: [] }),
    }),
    { name: "glowmart-wishlist" }
  )
);
