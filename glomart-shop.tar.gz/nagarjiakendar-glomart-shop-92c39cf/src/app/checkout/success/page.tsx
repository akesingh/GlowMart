import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2 } from "lucide-react";

export const metadata: Metadata = {
  title: "Order Confirmed",
  description: "Your GlowMart order has been placed successfully.",
};

export default function CheckoutSuccessPage() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-20 text-center">
      <CheckCircle2 className="size-14 text-emerald-600" />
      <h1 className="font-heading mt-5 text-3xl text-[var(--ink)] sm:text-4xl">
        Order confirmed
      </h1>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
        Thank you for shopping with GlowMart. A confirmation email is on its way, and
        you can track your order from your account once shipping begins.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link
          href="/products"
          className="inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
        >
          Continue shopping
        </Link>
        <Link
          href="/"
          className="inline-flex h-11 items-center rounded-full border border-[var(--blush)] px-6 text-sm font-medium hover:bg-[var(--blush-soft)]"
        >
          Back to home
        </Link>
      </div>
    </div>
  );
}
