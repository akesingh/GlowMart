import type { Metadata } from "next";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Complete your GlowMart order securely.",
};

export default function CheckoutPage() {
  return <CheckoutFlow />;
}
