import type { Metadata } from "next";
import { CartPageClient } from "@/components/cart/cart-page-client";

export const metadata: Metadata = {
  title: "Shopping Bag",
  description: "Review items in your GlowMart shopping bag and proceed to checkout.",
};

export default function CartPage() {
  return <CartPageClient />;
}
