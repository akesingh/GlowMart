import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getProductBySlug,
  getRelatedProducts,
  getReviewsForProduct,
} from "@/services/product-service";
import { ProductDetail } from "@/components/product/product-detail";
import { ProductCarousel } from "@/components/home/product-carousel";
import { products } from "@/data/products";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: `${product.name} — ${product.brand}`,
    description: product.description,
    openGraph: {
      title: product.name,
      description: product.description,
      images: product.images,
    },
  };
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, related] = await Promise.all([
    getReviewsForProduct(product.id),
    getRelatedProducts(product),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:py-10">
      <nav aria-label="Breadcrumb" className="mb-6 text-xs text-muted-foreground">
        <ol className="flex flex-wrap items-center gap-1.5">
          <li>
            <Link href="/" className="hover:text-[var(--rose-deep)]">
              Home
            </Link>
          </li>
          <li>/</li>
          <li>
            <Link
              href={`/products?category=${product.category}`}
              className="capitalize hover:text-[var(--rose-deep)]"
            >
              {product.category.replace("-", " ")}
            </Link>
          </li>
          <li>/</li>
          <li className="truncate text-[var(--ink)]">{product.name}</li>
        </ol>
      </nav>

      <ProductDetail product={product} reviews={reviews} />

      {related.length > 0 && (
        <div className="mt-16">
          <ProductCarousel
            eyebrow="You may also like"
            title="Related products"
            products={related}
            href={`/products?category=${product.category}`}
          />
        </div>
      )}
    </div>
  );
}
