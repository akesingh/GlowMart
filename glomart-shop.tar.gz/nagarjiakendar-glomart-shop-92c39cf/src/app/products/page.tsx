import type { Metadata } from "next";
import { Suspense } from "react";
import { ProductsPageClient } from "@/components/product/products-page-client";
import { ProductGrid } from "@/components/product/product-grid";

export const metadata: Metadata = {
  title: "Shop All Products",
  description:
    "Browse makeup, skincare, haircare, fragrance and more. Filter by brand, price, rating and category at GlowMart.",
};

export default function ProductsPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-7xl px-4 py-10">
          <div className="mb-6 h-10 w-48 animate-pulse rounded bg-[var(--blush-soft)]" />
          <ProductGrid products={[]} loading skeletonCount={8} />
        </div>
      }
    >
      <ProductsPageClient />
    </Suspense>
  );
}
