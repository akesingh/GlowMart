import type { Metadata } from "next";
import { Cormorant_Garamond, Plus_Jakarta_Sans } from "next/font/google";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { MobileNav } from "@/components/layout/mobile-nav";
import { Providers } from "@/components/providers";
import "./globals.css";

const plusJakarta = Plus_Jakarta_Sans({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const cormorant = Cormorant_Garamond({
  variable: "--font-heading",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: {
    default: "GlowMart — Premium Beauty & Cosmetics",
    template: "%s | GlowMart",
  },
  description:
    "Shop makeup, skincare, haircare, fragrance and more at GlowMart — a premium beauty marketplace with authentic brands, curated deals, and effortless shopping.",
  keywords: [
    "beauty",
    "cosmetics",
    "skincare",
    "makeup",
    "perfume",
    "GlowMart",
    "online beauty store",
  ],
  openGraph: {
    title: "GlowMart — Premium Beauty & Cosmetics",
    description:
      "Your curated destination for makeup, skincare, haircare, and fragrance.",
    type: "website",
    siteName: "GlowMart",
  },
  metadataBase: new URL("https://glowmart.example.com"),
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${plusJakarta.variable} ${cormorant.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col font-sans">
        <Providers>
          <Header />
          <main className="flex-1 pb-20 lg:pb-0">{children}</main>
          <Footer />
          <MobileNav />
        </Providers>
      </body>
    </html>
  );
}
