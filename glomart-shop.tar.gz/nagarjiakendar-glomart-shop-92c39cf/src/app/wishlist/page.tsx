import type { Metadata } from "next";
import { WishlistPageClient } from "@/components/wishlist/wishlist-page-client";

export const metadata: Metadata = {
  title: "Wishlist",
  description: "Your saved beauty favorites at GlowMart.",
};

export default function WishlistPage() {
  return <WishlistPageClient />;
}
