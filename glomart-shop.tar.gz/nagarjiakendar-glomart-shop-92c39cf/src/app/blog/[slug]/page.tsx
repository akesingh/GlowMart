import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { blogPosts } from "@/data/blogs";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) return { title: "Article not found" };
  return { title: post.title, description: post.excerpt };
}

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      <Link href="/blog" className="text-sm text-[var(--rose-deep)] hover:underline">
        ← All articles
      </Link>
      <p className="mt-6 text-[11px] font-semibold tracking-wider text-[var(--rose-deep)] uppercase">
        {post.category} · {post.readTime} · {post.author}
      </p>
      <h1 className="font-heading mt-2 text-4xl leading-tight text-[var(--ink)] sm:text-5xl">
        {post.title}
      </h1>
      <p className="mt-4 text-muted-foreground">{post.excerpt}</p>
      <div className="relative mt-8 aspect-[16/9] overflow-hidden rounded-2xl">
        <Image src={post.image} alt="" fill className="object-cover" priority sizes="800px" />
      </div>
      <div className="prose prose-stone mt-8 max-w-none text-[var(--ink)]/80">
        <p>
          At GlowMart, we believe beauty should feel considered — not complicated. This guide
          walks through practical steps you can start today, with product picks you&apos;ll find
          across our marketplace.
        </p>
        <p className="mt-4">
          Whether you&apos;re refining a morning ritual or building a weekend glam look, focus on
          texture, finish, and how formulas layer together. Authenticity and skin comfort always
          come first.
        </p>
        <p className="mt-4">
          Explore related products in our shop and save your favorites to wishlist while you
          plan your next haul.
        </p>
      </div>
      <Link
        href="/products"
        className="mt-10 inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
      >
        Shop the edit
      </Link>
    </article>
  );
}
