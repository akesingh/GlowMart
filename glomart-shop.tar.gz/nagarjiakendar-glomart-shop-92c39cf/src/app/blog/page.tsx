import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { getBlogPosts } from "@/services/product-service";

export const metadata: Metadata = {
  title: "Beauty Blog",
  description: "Skincare tips, makeup guides, and fragrance stories from the GlowMart Journal.",
};

export default function BlogPage() {
  const posts = getBlogPosts();

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      <p className="text-[11px] font-semibold tracking-[0.18em] text-[var(--rose-deep)] uppercase">
        GlowMart Journal
      </p>
      <h1 className="font-heading mt-1 text-4xl text-[var(--ink)]">Beauty content</h1>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">
        Expert routines, product guides, and seasonal edits from our beauty editors.
      </p>
      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/blog/${post.slug}`}
            className="group overflow-hidden rounded-2xl border border-[var(--blush)] bg-white transition hover:-translate-y-1 hover:shadow-lg"
          >
            <div className="relative aspect-[16/9]">
              <Image src={post.image} alt="" fill className="object-cover" sizes="50vw" />
            </div>
            <div className="p-5">
              <p className="text-[11px] font-semibold tracking-wider text-[var(--rose-deep)] uppercase">
                {post.category} · {post.readTime} · {post.author}
              </p>
              <h2 className="font-heading mt-2 text-2xl text-[var(--ink)] group-hover:text-[var(--rose-deep)]">
                {post.title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">{post.excerpt}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
