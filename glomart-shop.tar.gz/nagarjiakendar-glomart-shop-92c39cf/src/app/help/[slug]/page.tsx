import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Help Center",
};

export default function HelpPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <h1 className="font-heading text-3xl">Help Center</h1>
      <p className="mt-3 text-muted-foreground">
        For this demo, support pages are informational placeholders. Reach out anytime —
        we&apos;re here to help with orders, returns, and product advice.
      </p>
      <Link href="/" className="mt-6 inline-block text-[var(--rose-deep)] hover:underline">
        Back to GlowMart
      </Link>
    </div>
  );
}
