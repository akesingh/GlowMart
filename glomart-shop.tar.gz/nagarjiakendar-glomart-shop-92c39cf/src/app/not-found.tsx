import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-24 text-center">
      <p className="text-[11px] font-semibold tracking-[0.2em] text-[var(--rose-deep)] uppercase">
        404
      </p>
      <h1 className="font-heading mt-2 text-4xl text-[var(--ink)]">Page not found</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        The page you&apos;re looking for doesn&apos;t exist or has moved.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex h-11 items-center rounded-full bg-[var(--ink)] px-6 text-sm font-medium text-white hover:bg-[var(--rose-deep)]"
      >
        Return home
      </Link>
    </div>
  );
}
