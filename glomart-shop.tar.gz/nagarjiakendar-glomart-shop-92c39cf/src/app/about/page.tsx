import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About GlowMart",
};

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-16">
      <h1 className="font-heading text-4xl text-[var(--ink)]">About GlowMart</h1>
      <p className="mt-4 text-muted-foreground leading-relaxed">
        GlowMart is a premium beauty marketplace built to make discovering makeup, skincare,
        haircare, and fragrance feel effortless. We partner with thoughtful brands and curate
        edits that balance performance, texture, and everyday wearability.
      </p>
      <Link href="/products" className="mt-8 inline-block text-[var(--rose-deep)] hover:underline">
        Explore the shop →
      </Link>
    </div>
  );
}
