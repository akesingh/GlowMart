import type { Metadata } from "next";
import { HeroBanner } from "@/components/home/hero-banner";
import { CategoryGrid } from "@/components/home/category-grid";
import { ProductCarousel } from "@/components/home/product-carousel";
import { DealsSection } from "@/components/home/deals-section";
import { BrandsSection } from "@/components/home/brands-section";
import { BlogSection } from "@/components/home/blog-section";
import { TrustIndicators } from "@/components/home/trust-indicators";
import { Newsletter } from "@/components/home/newsletter";
import {
  getBestSellers,
  getDeals,
  getNewArrivals,
  getTrendingProducts,
} from "@/services/product-service";

export const metadata: Metadata = {
  title: "GlowMart — Premium Beauty & Cosmetics Marketplace",
  description:
    "Discover trending makeup, skincare, haircare and fragrance. Shop bestsellers, new arrivals and exclusive beauty deals at GlowMart.",
};

export default async function HomePage() {
  const [trending, bestSellers, newArrivals, deals] = await Promise.all([
    getTrendingProducts(),
    getBestSellers(),
    getNewArrivals(),
    getDeals(),
  ]);

  return (
    <>
      <HeroBanner />
      <CategoryGrid />
      <ProductCarousel
        eyebrow="Now trending"
        title="Trending products"
        products={trending}
        href="/products?sort=relevance"
      />
      <DealsSection products={deals} />
      <ProductCarousel
        eyebrow="Customer favorites"
        title="Best sellers"
        products={bestSellers}
        href="/products?sort=rating"
      />
      <BrandsSection />
      <ProductCarousel
        eyebrow="Just dropped"
        title="New arrivals"
        products={newArrivals}
        href="/products?sort=newest"
      />
      <TrustIndicators />
      <BlogSection />
      <Newsletter />
    </>
  );
}
