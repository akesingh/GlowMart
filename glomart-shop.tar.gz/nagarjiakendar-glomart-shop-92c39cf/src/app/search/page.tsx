import type { Metadata } from "next";
import { Suspense } from "react";
import { SearchPageClient } from "@/components/product/search-page-client";
import { ProductGrid } from "@/components/product/product-grid";

export const metadata: Metadata = {
  title: "Search",
  description: "Search GlowMart for makeup, skincare, haircare, fragrance and beauty tools.",
};

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-7xl px-4 py-10">
          <div className="mb-6 h-10 w-40 animate-pulse rounded bg-[var(--blush-soft)]" />
          <ProductGrid products={[]} loading />
        </div>
      }
    >
      <SearchPageClient />
    </Suspense>
  );
}
