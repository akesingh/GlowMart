import type { Metadata } from "next";
import Link from "next/link";
import { User, Package, Heart, MapPin, CreditCard } from "lucide-react";

export const metadata: Metadata = {
  title: "My Account",
  description: "Manage your GlowMart account, orders, and preferences.",
};

const links = [
  { href: "/cart", label: "Orders & bag", icon: Package, desc: "View cart and recent orders" },
  { href: "/wishlist", label: "Wishlist", icon: Heart, desc: "Saved beauty favorites" },
  { href: "/checkout", label: "Addresses", icon: MapPin, desc: "Manage delivery details at checkout" },
  { href: "/checkout", label: "Payment methods", icon: CreditCard, desc: "Choose how you pay" },
];

export default function AccountPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      <div className="flex items-center gap-4">
        <span className="flex size-14 items-center justify-center rounded-full bg-[var(--blush-soft)] text-[var(--rose-deep)]">
          <User className="size-7" />
        </span>
        <div>
          <h1 className="font-heading text-3xl text-[var(--ink)]">My account</h1>
          <p className="text-sm text-muted-foreground">
            Sign-in is mocked for this demo — explore orders, wishlist, and checkout freely.
          </p>
        </div>
      </div>
      <ul className="mt-10 space-y-3">
        {links.map(({ href, label, icon: Icon, desc }) => (
          <li key={label}>
            <Link
              href={href}
              className="flex items-center gap-4 rounded-2xl border border-[var(--blush)] bg-white p-4 transition hover:border-[var(--rose)]/40 hover:shadow-sm"
            >
              <span className="flex size-10 items-center justify-center rounded-full bg-[var(--blush-soft)] text-[var(--rose-deep)]">
                <Icon className="size-5" />
              </span>
              <span>
                <span className="block font-medium text-[var(--ink)]">{label}</span>
                <span className="text-sm text-muted-foreground">{desc}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
