import { products } from "@/data/products";
import { categories } from "@/data/categories";
import { brands } from "@/data/brands";
import { reviews } from "@/data/reviews";
import { blogPosts } from "@/data/blogs";
import type {
  CategorySlug,
  Product,
  ProductFilters,
  SortOption,
} from "@/lib/types";

function sortProducts(list: Product[], sort: SortOption = "relevance"): Product[] {
  const sorted = [...list];
  switch (sort) {
    case "price-asc":
      return sorted.sort((a, b) => a.price - b.price);
    case "price-desc":
      return sorted.sort((a, b) => b.price - a.price);
    case "rating":
      return sorted.sort((a, b) => b.rating - a.rating);
    case "newest":
      return sorted.sort((a, b) => Number(b.isNewArrival) - Number(a.isNewArrival));
    case "discount":
      return sorted.sort((a, b) => b.discount - a.discount);
    default:
      return sorted.sort((a, b) => b.reviewCount - a.reviewCount);
  }
}

export async function getProducts(filters: ProductFilters = {}): Promise<Product[]> {
  // Simulate network latency for realistic loading UX
  await delay(120);
  let result = [...products];

  if (filters.search) {
    const q = filters.search.toLowerCase();
    result = result.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.includes(q) ||
        p.subcategory.toLowerCase().includes(q) ||
        p.tags.some((t) => t.includes(q))
    );
  }

  if (filters.categories?.length) {
    result = result.filter((p) => filters.categories!.includes(p.category));
  }

  if (filters.brands?.length) {
    result = result.filter((p) =>
      filters.brands!.some((b) => b.toLowerCase() === p.brandSlug || b.toLowerCase() === p.brand.toLowerCase())
    );
  }

  if (filters.minPrice !== undefined) {
    result = result.filter((p) => p.price >= filters.minPrice!);
  }

  if (filters.maxPrice !== undefined) {
    result = result.filter((p) => p.price <= filters.maxPrice!);
  }

  if (filters.minRating !== undefined) {
    result = result.filter((p) => p.rating >= filters.minRating!);
  }

  if (filters.badges?.length) {
    result = result.filter((p) =>
      filters.badges!.some((b) => p.badges.includes(b))
    );
  }

  if (filters.inStock) {
    result = result.filter((p) => p.inStock);
  }

  return sortProducts(result, filters.sort);
}

export async function getProductBySlug(slug: string): Promise<Product | undefined> {
  await delay(80);
  return products.find((p) => p.slug === slug);
}

export async function getProductById(id: string): Promise<Product | undefined> {
  await delay(40);
  return products.find((p) => p.id === id);
}

export async function getProductsByIds(ids: string[]): Promise<Product[]> {
  await delay(60);
  return products.filter((p) => ids.includes(p.id));
}

export async function getTrendingProducts(): Promise<Product[]> {
  await delay(100);
  return products.filter((p) => p.isTrending).slice(0, 10);
}

export async function getBestSellers(): Promise<Product[]> {
  await delay(100);
  return products.filter((p) => p.isBestSeller).slice(0, 10);
}

export async function getNewArrivals(): Promise<Product[]> {
  await delay(100);
  return products.filter((p) => p.isNewArrival).slice(0, 10);
}

export async function getDeals(): Promise<Product[]> {
  await delay(100);
  return products.filter((p) => p.isDeal || p.discount >= 25).slice(0, 10);
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  await delay(80);
  return products
    .filter((p) => p.id !== product.id && (p.category === product.category || p.brandSlug === product.brandSlug))
    .slice(0, limit);
}

export async function getReviewsForProduct(productId: string) {
  await delay(60);
  return reviews.filter((r) => r.productId === productId);
}

export function getCategories() {
  return categories;
}

export function getCategoryBySlug(slug: string) {
  return categories.find((c) => c.slug === slug);
}

export function getBrands() {
  return brands;
}

export function getFeaturedBrands() {
  return brands.filter((b) => b.featured);
}

export function getBlogPosts() {
  return blogPosts;
}

export function getCategoryProductCount(slug: CategorySlug) {
  return products.filter((p) => p.category === slug).length;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
