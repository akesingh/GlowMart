import { products } from "@/data/products";
import { categories } from "@/data/categories";
import { brands } from "@/data/brands";
import type { Product } from "@/lib/types";

export interface SearchSuggestion {
  type: "product" | "category" | "brand" | "query";
  label: string;
  href: string;
  meta?: string;
  image?: string;
}

const popularQueries = [
  "vitamin c serum",
  "matte lipstick",
  "sunscreen spf 50",
  "hair oil",
  "perfume for women",
  "foundation",
  "beard oil",
  "jade roller",
];

export async function searchProducts(query: string, limit = 24): Promise<Product[]> {
  await delay(100);
  const q = query.trim().toLowerCase();
  if (!q) return [];

  return products
    .filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.subcategory.toLowerCase().includes(q) ||
        p.tags.some((t) => t.includes(q)) ||
        p.category.replace("-", " ").includes(q)
    )
    .slice(0, limit);
}

export async function getSearchSuggestions(query: string): Promise<SearchSuggestion[]> {
  await delay(80);
  const q = query.trim().toLowerCase();
  if (!q) {
    return popularQueries.map((label) => ({
      type: "query" as const,
      label,
      href: `/search?q=${encodeURIComponent(label)}`,
    }));
  }

  const suggestions: SearchSuggestion[] = [];

  const matchedCategories = categories.filter(
    (c) =>
      c.name.toLowerCase().includes(q) ||
      c.subcategories.some((s) => s.toLowerCase().includes(q))
  );
  matchedCategories.slice(0, 3).forEach((c) => {
    suggestions.push({
      type: "category",
      label: c.name,
      href: `/products?category=${c.slug}`,
      meta: "Category",
    });
  });

  const matchedBrands = brands.filter((b) => b.name.toLowerCase().includes(q));
  matchedBrands.slice(0, 3).forEach((b) => {
    suggestions.push({
      type: "brand",
      label: b.name,
      href: `/products?brand=${b.slug}`,
      meta: "Brand",
    });
  });

  const matchedProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.tags.some((t) => t.includes(q))
  );
  matchedProducts.slice(0, 5).forEach((p) => {
    suggestions.push({
      type: "product",
      label: p.name,
      href: `/products/${p.slug}`,
      meta: p.brand,
      image: p.images[0],
    });
  });

  popularQueries
    .filter((pq) => pq.includes(q))
    .slice(0, 3)
    .forEach((label) => {
      suggestions.push({
        type: "query",
        label,
        href: `/search?q=${encodeURIComponent(label)}`,
      });
    });

  return suggestions.slice(0, 10);
}

export function getPopularSearches() {
  return popularQueries;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
